#include <cs50.h>
#include <stdio.h>

int main(void)
{
    float a[3];
    float media = 0;
    for (int i = 0; i < 3; i++)
    {
        a[i] = get_float("Numarul %i = ", i + 1);
    }
    for (int i = 0; i < 3; i++)
    {
        media+= a[i]; 
    }
    printf("Meida : %.2f\n", media / 3);
}