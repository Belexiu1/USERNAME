#include <stdio.h>

float max(float salarii[], int n)
{
    /*

    */
}

float min(float salarii[], int n)
{
    float min = salarii[0];

    for (int i = 1; i < n; i++)
        if (salarii[i] < min)
            min = salarii[i];

    return min;
}

int main()
{
    float salarii[] = { 9800, 4300.50, 11000.80, 7400, 8000 };
    int n = sizeof(salarii) / sizeof(salarii[0]);

    float maxim = max(salarii, n);
    float minim = min(salarii, n);
    printf("max = %.2f min = %.2f", maxim, minim);
}
