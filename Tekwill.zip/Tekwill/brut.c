#include <stdio.h>

void print_numere(int a[], int n)
{
    for (int i = 1; i <= n; i++)
        printf("%d", a[i]);

    printf("\n");
}


int main()
{
    int a[100];
    int min = 0;
    int max = 9;
    int n = 3;
    int ultim;

    for (int i = 0; i <= n; i++)
        a[i] = min;

    while (a[0] == min)
    {
        print_numere(a, n);
        ultim = n;
        while(a[ultim] == max)
        {
            a[ultim] = min;
            ultim--;
        }
        a[ultim]++;
    }

}