#include <stdio.h>

void afisaretablou(int x[], int n)
{
    for (int i = 0; i < n; i++)
        printf("%d ", x[i]);

    return;
}

void sortare(int x[], int n)
{
    int e_permutat;
    do
    {
        e_permutat = 0;
        for (int i = 0; i < n - 1; i++)
        if (x[i] > x[i + 1])
        {
            int tmp = x[i];
            x[i] = x[i + 1];
            x[ i + 1] = tmp;
            e_permutat = 1;
        }
    } while (e_permutat == 1);
}

int main()
{
    int a[] = { 101, 45, -23, 0, -5, 77, 44, 3, 2 };
    int n = sizeof(a) / sizeof(a[0]);

    sortare(a, n);
    afisaretablou(a, n);
}