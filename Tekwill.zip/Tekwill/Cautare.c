#include <stdio.h>

void print(int a[7], int n)
{
    for (int i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }
    printf("\n");
}

void selection_sort(int a[7], int n)
{
    int min, pmin, tmp;
    for(int j = n; j > 0 ; j--)
    {
        min = a[1]; pmin = 1;
        for (int i = 0 ; i <= j ; i++)
        {
            if(min > a[i])
            {
                min = a[i];
                pmin = i;
            }
        }
        printf("%i ", min);
        tmp = a[j];
        a[j] = min;
        a[pmin] = tmp ;
    }
    printf("\n");
}
int main()
{
    int a[7] = {49, 32, 15, -5, 3, -5, 101};
    int n = sizeof(a) / sizeof(a[0]);

    selection_sort(a, n);
    print(a, n);
}