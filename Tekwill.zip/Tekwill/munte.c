#include <stdio.h>

#define N 3
#define M 4

int main()
{
    int min, i_min, j_min;
    int h[N][M] =
    {
        {15, 20 , 45, 101},
        {18, 32, 4, 88},
        {77, 45, 160, 44}
    };

    i_min = j_min = 0;
    min = h[0][0];

    for (int i = 0; i < N; i++)
        for (int j = 0; j < M; j++)
            if (h[i][j] < min)
            {
                min = h[i][j];
                i_min = i;
                j_min = j;
            }

    printf("Inaltimea minima: %d. ", min);
    printf("Coordonatele: %d %d\n.", i_min, j_min);

    return 0;
}