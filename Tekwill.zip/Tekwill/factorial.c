#include <stdio.h>

int factorial(int n)
{
    int N = n;
    if (N == 1)
    {
        return 1;
    }
    else if (N > 1 && N != 0)
    {
        for (int i = 1 ; i < n ; i++)
        {
            N = N * i;
        }
        return N;
    }
    return 0;
}


int main()
{
    printf("6 = %d", factorial(6));
}