#include <stdio.h>
int cmmdc(int a, int b)
{
    int A = a;
    int B = b;
    do
    {
    while( A > B )
    {
        A = A -B;
        while( B > A)
        {
            B= B - A;
        }
    }
    }while (a == b);
    
    return B ;
}

int main(void)
{
    int a, b;
    
    int result1 = cmmdc(30, 18);
    int result2 = cmmdc(27, 9);
    int result3 = cmmdc(170, 2110);
    
    printf("%d %d %d\n", result1, result2, result3);
}
