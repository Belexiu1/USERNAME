#include <stdio.h>
#include <cs50.h>
#include <limits.h>
#include <math.h>

public void lcm(int a, int b)
{
    int max = 0;
    int min = 0;
    int A = a;
    int B = b;
    if (a > b)
    {
        min = b;
        max = a;
    }
    else
    {
        min = a;
        max = b;
    }
    for (i = 1; i < max; i++)
    {
        if ((min*i)%max == 0)
        {
            res = min*i;
            break;
        }
    }
    Console.Write("{0}", res);
}
int main(void)
{
    int a = get_int("Numarul a = ");
    int b = get_int("Numarul b = ");
    
    int multiplu = lcm(a, b);
    printf("Multiplu este : %i", multiplu);
}