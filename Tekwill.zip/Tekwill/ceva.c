/*Scrie o funсție – index_of(), care primește ca parametru numărul căutat (int), tabloul de numere (int) și mărimea tabloului (int) și care va returna indicele la numărul căutat în tabloul de numere întregi. Dacă elementul nu este prezent în tablou, funcția returnează -1. Dacă în tablou sunt duplicate, se returnează indicele la prima apariție.  Funcția main rămîne neatinsă.

Exemplu:

int a[4] = {5, 19, -3, 19};

index_of(5, a, 4); // va returna 0

index_of(123, a, 4); // va returna -1

index_of(19, a, 4); // va returna 1

index_of(-3, a, 4); // va returna 2

#include <stdio.h>

/* lipseste functia */

int main()
{
    int a[] = { 100, 32, -5, -1, 0, 55, 32 };
    int n = sizeof(a) / sizeof(a[0]);

    int index1 = index_of(100, a, n);
    int index2 = index_of(32, a, n);
    int index3 = index_of(-1, a, n);
    int index4 = index_of(101, a, n);

    printf("%d %d %d %d", index1, index2, index3, index4);
}
