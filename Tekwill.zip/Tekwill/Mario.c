#include <stdio.h>
#define N 7
int main (void)
{
  int a[N] = { 103, 2, -1, -5, 17, 301, -4 };
     for(int i = 0 ; i < N ; i++)
     {
         if( a[i] > 0)
         {
             if(i % 2)
             {
               printf("%i ", a[i]);  
             }
         }
             
     }

  return 0;
}