#include <stdio.h>
#include <cs50.h>
#include <limits.h>

int algoritmul(int numar ,int lungimea, int a[lungimea])
{
   int mid = lungimea / 2;
   for (int i = 0 ; i < lungimea ; i++)
   {
        if (a[mid] == numar)
        {
            return mid;
        }
        else if(a[mid] < numar)
        {
            if ( mid % 2 == 0)
            {
                mid = (mid / 2) + mid;
            }
            else
            {
                mid++;
            }
        }
        else if (a[mid] > numar)
        {
            if (a[mid] % 2 == 0)
            {
                mid =mid / 2;
            }
            else
            {
                mid--;
            }
        }
   }
   return 0 ;
}

int main (void)
{
    int n = get_int("Numarul de elemente ale tabloului : ");
    int tablou[n];
    int min = INT_MIN;
    for (int i = 0; i < n ; i++)
    {
        do
        {
            tablou[i] = get_int("Numarul %i : ", i + 1);
        }while (tablou[i] < min);
        if (tablou[i] > min)
        {
                min = tablou[i];
        }
    }
    if (n % 2 != 0)
    {
        n++;
    }
    int cautare = get_int ("numarul pe care il cauti : ");
    int rezultat = algoritmul(cautare ,n , &tablou[n]);
    printf("Pozitia %i\n", rezultat + 1);
    
}