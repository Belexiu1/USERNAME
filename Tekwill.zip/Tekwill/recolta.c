#include <stdio.h>

#define N 4
#define M 5

int main()
{
    int suma;
    int lan[N][M] =
    {
        {60, 32, 72, 101, 55},
        {30, 44, 22, 31, 17},
        {33, 23, 65, 109, 16},
        {32, 15, 78, 82, 20}
    };

    for (int i = 0; i < N; i++)
    {
        for(int j = 0; j < M; j++)
            if( lan[i][j] > 20)
           {
                suma = suma + lan[i][j];
            }
    }
    printf("Recolta : %i\n", suma);
    
    



    return 0;
}