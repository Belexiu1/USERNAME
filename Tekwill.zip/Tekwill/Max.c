#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int a[3];
    int max;
    for (int i = 0; i < 3 ; i++)
    {
        a[i] = get_int("Numarul %i = ", i + 1 );
    }
    max = a[0];
    for(int i = 0; i < 3; i++)
    {
        if(a[i] > max)
        {
            max = a[i];
        }
    }
    printf("%i\n", max);
}